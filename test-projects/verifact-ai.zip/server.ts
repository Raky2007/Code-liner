import express from "express";
import cors from "cors";
import path from "path";
import "dotenv/config";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

// Lazy initialization of GoogleGenAI to ensure environment variables are loaded
let aiInstance: GoogleGenAI | null = null;

function getAI() {
  if (!aiInstance) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY is not set or is invalid. Please configure it in the Secrets panel.");
    }
    aiInstance = new GoogleGenAI({ apiKey });
  }
  return aiInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // --- API Routes ---

  /**
   * Helper to fetch with retry for 429/5xx errors
   */
  async function fetchWithRetry(url: string, options: RequestInit, maxRetries = 3, initialDelay = 1000): Promise<Response> {
    let retries = 0;
    while (true) {
      try {
        const response = await fetch(url, options);
        if (response.status === 429 || (response.status >= 500 && response.status <= 599)) {
          if (retries < maxRetries) {
            const delay = initialDelay * Math.pow(2, retries);
            console.warn(`Fetch error ${response.status}. Retrying in ${delay}ms... (Attempt ${retries + 1}/${maxRetries})`);
            await new Promise(resolve => setTimeout(resolve, delay));
            retries++;
            continue;
          }
        }
        return response;
      } catch (error) {
        if (retries < maxRetries) {
          const delay = initialDelay * Math.pow(2, retries);
          console.warn(`Fetch network error. Retrying in ${delay}ms... (Attempt ${retries + 1}/${maxRetries})`);
          await new Promise(resolve => setTimeout(resolve, delay));
          retries++;
          continue;
        }
        throw error;
      }
    }
  }

  // Proxy for Tavily Search (to keep API key secure)
  app.post("/api/search", async (req, res) => {
    try {
      const { query } = req.body;
      const searchApiKey = process.env.SEARCH_API_KEY;

      if (!searchApiKey || searchApiKey === "" || searchApiKey.includes("tvly-dev-")) {
        // If key is provided in request or env, use it. 
        // Note: In a real app, you'd strictly use process.env.
      }

      const apiKeyToUse = searchApiKey || "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";

      const searchResponse = await fetchWithRetry("https://api.tavily.com/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          api_key: apiKeyToUse,
          query: query,
          search_depth: "advanced",
          max_results: 5
        })
      });

      if (!searchResponse.ok) {
        throw new Error(`Tavily search failed: ${searchResponse.statusText}`);
      }

      const searchData = await searchResponse.json();
      const sources = searchData.results.map((r: any) => ({
        title: r.title,
        url: r.url,
        snippet: r.content
      }));

      res.json({ sources });
    } catch (error: any) {
      console.error("Search error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
